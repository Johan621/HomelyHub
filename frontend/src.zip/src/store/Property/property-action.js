import { propertyAction } from "./property-slice.js";
import {axiosInstance} from "../../utils/axios.js";

//get all properties
//1. start api req
//2. Tell redux loading started
//3. Get seaarch parameters
//4. call backend api
//5. wait for response
//6. Get property data
//7. send data to redux store
//8. If error => send error to redux

//dispatch => send to redux
//getstate => get data from redux

export const getAllProperties = ()=> async(dispatch, getState)=>{
    try{
        console.log("API call started");

        dispatch(propertyAction.getRequest())

        const {searchParams} = getState().properties

        console.log(searchParams)

        const response = await axiosInstance.get(`/v1/rent/listing`,{
            params:{...searchParams}
        })

        if(!response){
            throw new Error("Could not fetch any properties")
        }

        const {data} = response;
        console.log(data);

        dispatch(propertyAction.getProperties(data))

    }catch(error){
        dispatch(propertyAction.getErrors(error.message))
    }
}